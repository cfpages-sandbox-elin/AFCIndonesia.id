{{ ucfunc("put_docready_start") }}
		
 var objWrapper = jQuery("#{{uc_id}}");
  
  var api = objWrapper.unitegallery({
    gallery_theme:"carousel",
    gallery_width:"{{gallery_width}}",
    tile_width: {{tile_width_nounit}},
    tile_height: {{tile_height_nounit}},
    tile_enable_outline: {{tile_enable_outline}},
    tile_show_video_play_icons_always: {{show_play_icon_always}},
    tile_as_link: {{tile_as_link}},
    tile_link_newpage: {{tile_link_newpage}},
    tile_enable_icons: {{tile_enable_icons}},
    tile_icon_type: "{{tile_icons_type}}",				//tile icon type: default / custom
	tile_zoom_icon_color: "{{zoom_icon_color_def}}",      //tile icon color
	tile_play_icon_color: "{{play_icon_color_def}}",      //tile icon color
	tile_link_icon_color: "{{link_icon_color_def}}",      //tile icon color
	tile_zoom_icon_custom: "{{tile_zoom_icon_custom_html|ucsafe|raw}}",				//tile zoom icon type: default / custom
	tile_play_icon_custom: "{{tile_play_icon_custom_html|ucsafe|raw}}",				//tile play icon type: default / custom
	tile_link_icon_custom: "{{tile_link_icon_custom_html|ucsafe|raw}}",				//tile link icon type: default / custom                                  
    tile_overlay_opacity: {{tile_overlay_opacity_nounit}},
    tile_overlay_color: "{{tile_overlay_color}}", 
    tile_background_color: "{{tile_background_color}}",
                       
    carousel_space_between_tiles: {{carousel_space_between_tiles_nounit}},		
	carousel_navigation_numtiles:{{carousel_navigation_numtiles}},			
	carousel_scroll_duration:{{carousel_scroll_duration}},			
	carousel_scroll_easing:"{{carousel_scroll_easing}}",	
	carousel_autoplay: {{carousel_autoplay}},				
	carousel_autoplay_timeout: {{carousel_autoplay_timeout}},		
	carousel_autoplay_direction: "{{carousel_autoplay_direction}}",	
	carousel_autoplay_pause_onhover: {{carousel_autoplay_pause_onhover}},
    
    theme_enable_navigation: {{theme_enable_navigation}},
    theme_navigation_position: "{{theme_navigation_position}}",
    theme_navigation_enable_play: {{navigation_enable_play}},
    theme_navigation_play_icon_type: "{{play_pause_icon_type}}",     //default, custom - type of the icon
	theme_navigation_play_icon: "{{nav_play_icon_html|ucsafe|raw}}", //play icon (if custom)
	theme_navigation_pause_icon: "{{nav_pause_icon_html|ucsafe|raw}}", //play icon (if custom)
	theme_navigation_play_icon_size: {{play_pause_icon_size_nounit}}, //size of the icon
	theme_navigation_play_btn_size: {{play_pause_btn_size_nounit}}, //size of the btn
	theme_navigation_play_icon_color: "{{play_pause_icon_color}}", //icon color
	theme_navigation_play_bg_color: "{{play_pause_icon_bg_color}}", //icon color
	theme_navigation_play_border_radius: 4, //border radius of the icon                                
    theme_navigation_align: "{{theme_navigation_align}}",		
	theme_navigation_margin: {{theme_arrows_margin_nounit}},			
	theme_space_between_arrows: {{theme_space_between_arrows_nounit}},
    theme_navigation_arrows_type: "{{arrows_icon_type}}",	//default, custom - type of the arrows
	theme_navigation_arrows_next_icon: "{{arrows_icon_next_html|ucsafe|raw}}",	//next icon (if custom)
	theme_navigation_arrows_prev_icon: "{{arrows_icon_prev_html|ucsafe|raw}}",	//prev icon (if custom)
	theme_navigation_arrows_icon_size: {{arrows_icon_size_nounit}},	//size of the arrows
    theme_navigation_arrows_btn_size: {{arrows_btn_size_nounit}},	//size of the arrows
	theme_navigation_arrows_icon_color: "{{arrows_icon_color}}",	//color of the arrow icons
	theme_navigation_arrows_bg_color: "{{arrows_icon_bg_color}}",	//color of the arrow bg
	theme_navigation_arrows_border_radius: 4,	//border radius of the arrows                                      
                                    
    tile_enable_textpanel:{{tile_enable_textpanel}},
    tile_textpanel_always_on: {{tile_textpanel_always_on}},
    tile_textpanel_appear_type: "{{tile_textpanel_appear_type}}",
    tile_textpanel_position:"{{tile_textpanel_position}}",
    tile_textpanel_padding_top:{{tile_textpanel_padding_nounit}},		 	
	tile_textpanel_padding_bottom:{{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_right: {{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_left: {{tile_textpanel_padding_nounit}},
    tile_textpanel_bg_color:"{{tile_textpanel_bg_color}}",
    tile_textpanel_bg_opacity:{{tile_textpanel_bg_opacity_nounit}},
    tile_textpanel_title_text_align:"{{tile_textpanel_title_text_align}}",
    tile_textpanel_title_color:"{{tile_textpanel_title_color}}",
                                    
                                    
    {% if tile_enable_border == "true" %}
        tile_enable_border:{{tile_enable_border}},
        tile_border_color:"{{tile_border_color}}",
        tile_border_width:{{tile_border_width_nounit}},
        tile_border_radius:{{tile_border_radius_nounit}}, 
        
    {% endif %}	

    {% if tile_enable_shadow == "true" %}
        tile_enable_shadow:{{tile_enable_shadow}},
        tile_shadow_color:"{{tile_shadow_color}}",
        tile_shadow_h:{{tile_shadow_h_nounit}},					
		tile_shadow_v:{{tile_shadow_v_nounit}},					
		tile_shadow_blur:{{tile_shadow_blur_nounit}},					
		tile_shadow_spread:{{tile_shadow_spread_nounit}},
     {% endif %}                               
    
    {% if tile_enable_image_effect == "true" %}
        tile_enable_image_effect:{{tile_enable_image_effect}},
        tile_image_effect_type: "{{tile_image_effect_type}}",
        tile_image_effect_reverse: {{tile_image_effect_reverse}},
    {% endif %}
                                    
    lightbox_type: "{{lightbox_type}}",
    lightbox_hide_arrows_onvideoplay: {{lightbox_hide_arrows_onvideoplay}},
    lightbox_arrows_position: "{{lightbox_arrows_position}}",                                
    lightbox_overlay_color:"{{lightbox_overlay_color}}",
    lightbox_overlay_opacity:{{lightbox_overlay_opacity_nounit}},	
    lightbox_show_numbers: {{lightbox_show_numbers}},
    lightbox_show_textpanel: {{lightbox_show_textpanel}},
    lightbox_slider_control_swipe:{{lightbox_slider_control_swipe}},
    lightbox_slider_control_zoom:{{lightbox_slider_control_zoom}},
    lightbox_textpanel_title_text_align:"{{lightbox_textpanel_title_text_align}}",                    
    lightbox_slider_image_border: {{lightbox_slider_image_border}},
    lightbox_slider_image_border_width: {{lightbox_slider_image_border_width_nounit}},
    lightbox_slider_image_border_color: "{{lightbox_slider_image_border_color}}",
    lightbox_slider_image_border_radius: {{lightbox_slider_image_border_radius_nounit}},
	lightbox_close_icon_type: "{{lightbox_close_icon_type}}",        //close icon type: default, custom
 	lightbox_close_icon_color: "{{lightbox_close_icon_color_default}}",        //close icon color
    lightbox_close_icon_color_custom: "{{lightbox_close_icon_color_custom}}",  
	lightbox_close_icon_custom: "{{lightbox_close_icon_custom_html|ucsafe|raw}}",        //close icon custom html  
    lightbox_close_icon_size_custom: "{{lightbox_close_icon_size_custom_nounit}}",
    lightbox_arrows_type: "{{lightbox_arrows_icon_type}}",        //arrow type: default, custom
	lightbox_arrows_color: "{{lightbox_arrows_icon_color_default}}",        //arrow color
	lightbox_arrows_color_custom: "{{lightbox_arrows_icon_color_custom}}",        //arrow color
	lightbox_arrow_next_custom: "{{lightbox_arrows_icon_next_html|ucsafe|raw}}",        //arrow html
	lightbox_arrow_prev_custom: "{{lightbox_arrows_icon_prev_html|ucsafe|raw}}",        //arrow html
	lightbox_arrows_size_custom: {{lightbox_arrows_icon_size_custom_nounit}},        //arrow size custom
  });  
         
  function addVideoClass(){
    var objShowAlways = objWrapper.find(".ug-button-play-show-always");
   
    if(!objShowAlways || objShowAlways.length == 0)
      return(false);
    
    objShowAlways.each(function(){
      var objIcon = jQuery(this);
      var objParent = objIcon.parent();
    
      objParent.addClass("uc-video");
    });    
  }     
       
  addVideoClass(); 

   objWrapper.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      	
     api.changeItems(htmlItems);
     addVideoClass();
     
     if(!htmlItems)
        api.showMessageReplaceGallery("{{empty_message|ucsafe|raw}}");  
   });
    	
{{ ucfunc("put_docready_end") }}