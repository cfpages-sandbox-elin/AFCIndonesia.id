<div id="{{uc_id}}-wrapper">
  <div id="{{uc_id}}" class="uc-items-wrapper{{uc_filtering_addclass}}" data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
    {{put_items()}}  
  </div>
</div>