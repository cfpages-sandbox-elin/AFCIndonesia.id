#{{uc_id}}-wrapper{
  min-height: 1px;
}

#{{uc_id}}{  
  margin:0 auto;
  direction:{{direction}};
  display: none;  
}

{% if show_play_icon_always == "true" %}
#{{uc_id}} .uc-video{
  opacity: 1 !important;
}
{% endif %}

#{{uc_id}} .ug-button-tile-play .ug-button-tile-pause-icon{
  display: none;
}

#{{uc_id}} .ug-pause-icon .ug-button-tile-pause-icon{
  display: flex !important;
}