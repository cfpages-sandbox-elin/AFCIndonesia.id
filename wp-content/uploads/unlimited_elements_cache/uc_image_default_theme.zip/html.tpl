<div id="{{uc_id}}-wrapper">
  <div id="{{uc_id}}" class="uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" {{remote_parent.attributes|raw}} data-remote-type="gallery" data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
    {{put_items()}}
  </div>
</div>