{{ ucfunc("put_docready_start") }}
		
    var objGallery = jQuery("#{{uc_id}}");
    
    var api = objGallery.unitegallery({
      gallery_theme:"compact",
      theme_panel_position: "{{theme_panel_position}}",			//top, bottom, left, right - thumbs panel position
      theme_hide_panel_under_width: {{hide_thumbnail_panel_under_width}},		//hide panel under certain browser width, if null, don't hide
      
      // gallery options
      strip_thumbs_align: "left",
      gallery_width:'{{gallery_width_nounit}}%',							//gallery width		
      gallery_height:{{gallery_height_nounit}},							//gallery height
      gallery_min_width: 100,						//gallery minimal width when resizing
      gallery_min_height: 300,					//gallery minimal height when resizing
      gallery_skin:"default",						//default, alexis etc... - the global skin of the gallery. Will change all gallery items by default.
      gallery_images_preload_type:"minimal",		//all , minimal , visible - preload type of the images.
      
      gallery_autoplay:{{gallery_autoplay}},						//true / false - begin slideshow autoplay on start
      gallery_play_interval: {{gallery_play_interval}},				//play interval of the slideshow
      gallery_pause_on_mouseover: {{gallery_pause_on_mouseover}},			//true,false - pause on mouseover when playing slideshow true/false
      
      gallery_control_thumbs_mousewheel:{{gallery_control_thumbs_mousewheel}},	//true,false - enable / disable the mousewheel
      gallery_control_keyboard: {{gallery_control_keyboard}},				//true,false - enable / disble keyboard controls
      gallery_carousel:{{gallery_carousel}},						//true,false - next button on last image goes to first image.
      
      gallery_preserve_ratio: {{gallery_preserve_ratio}},				//true, false - preserver ratio when on window resize
      gallery_height_tablet:{{gallery_height_tablet_nounit}},                                
      gallery_height_mobile:{{gallery_height_mobile_nounit}},                                
      gallery_debug_errors:true,					//show error message when there is some error on the gallery area.
      slider_background_color:"{{slider_background_color}}",
      
      //slider options: 
      slider_video_autoplay: {{video_autoplay}},
      slider_scale_mode: "{{slider_scale_mode}}",	//fit: scale down and up the image to always fit the slider								
      slider_scale_mode_media: "fill",			//fit, down, full scale mode on media items
      slider_scale_mode_fullscreen: "down",		//fit, down, full scale mode on fullscreen.
      slider_item_padding_top: 0,					//padding top of the slider item
      slider_item_padding_bottom: 0,				//padding bottom of the slider item
      slider_item_padding_left: 0,				//padding left of the slider item
      slider_item_padding_right: 0,				//padding right of the slider item
      
      slider_transition: "{{slider_transition}}",					//fade, slide - the transition of the slide change
      slider_transition_speed:{{slider_transition_speed}},				//transition duration of slide change
      slider_transition_easing: "easeInOutQuad",	//transition easing function of slide change
      
      slider_control_swipe:{{slider_control_swipe}},					//true,false - enable swiping control
      slider_control_zoom:{{slider_control_zoom}},					//true, false - enable zooming control
      slider_zoom_max_ratio: {{slider_zoom_max_ratio}},					//max zoom ratio
      slider_loader_type: {{slider_loader_type}},						//shape of the loader (1-7)
      slider_loader_color:"white",
      
      slider_enable_bullets: {{slider_enable_bullets}},				//enable the bullets onslider element
      slider_bullets_skin: "",					//skin of the bullets, if empty inherit from gallery skin
      slider_bullets_space_between: {{slider_bullets_space_between}},			//set the space between bullets. If -1 then will be set default space from the skins
      slider_bullets_align_hor:"{{slider_bullets_align_hor}}",			//left, center, right - bullets horizontal align
      slider_bullets_align_vert:"{{slider_bullets_align_vert}}",			//top, middle, bottom - bullets vertical algin
      slider_bullets_offset_hor:{{slider_bullets_offset_hor}},				//bullets horizontal offset 
      slider_bullets_offset_vert:{{slider_bullets_offset_vert}},				//bullets vertical offset
                                      
      slider_enable_arrows: {{slider_enable_arrows}},					//enable arrows onslider element
      slider_arrows_skin: "",						//skin of the slider arrows, if empty inherit from gallery skin
      slider_arrow_left_align_hor:"left",	  		//left, center, right - left arrow horizonal align
      slider_arrow_left_align_vert:"{{slider_arrow_align_vert}}", 		//top, middle, bottom - left arrow vertical align
      slider_arrow_left_offset_hor:{{arrow_horizontal_offset}},		  	//left arrow horizontal offset
      slider_arrow_left_offset_vert:0,		  	//left arrow vertical offset
      slider_arrow_right_align_hor:"right",   	//left, center, right - right arrow horizontal algin
      slider_arrow_right_align_vert:"{{slider_arrow_align_vert}}", 	//top, middle, bottom - right arrow vertical align
      slider_arrow_right_offset_hor:{{arrow_horizontal_offset}},	   		//right arrow horizontal offset 
      slider_arrow_right_offset_vert:0,	   		//right arrow vertical offset
      slider_arrow_right_offset_vert:{{arrow_offset_vertical}},	   		//right arrow vertical offset      
      slider_arrow_left_offset_vert:{{arrow_offset_vertical}},		  	//left arrow vertical offset     
      slider_arrows_type: "{{arrows_icon_type}}",    //default / custom
      slider_arrows_custom_icon_right: "{{arrow_icon_right_html|ucsafe|raw}}", //custom arrow icon html
      slider_arrows_custom_icon_left: "{{arrow_icon_left_html|ucsafe|raw}}", //custom arrow icon html                                  
      
      slider_enable_progress_indicator: {{slider_enable_progress_indicator}},		 //enable progress indicator element
      slider_progress_indicator_type: "{{slider_progress_indicator_type}}",		 //pie, pie2, bar (if pie not supported, it will switch to bar automatically)
      slider_progress_indicator_align_hor:"{{slider_progress_indicator_align_hor}}",  //left, center, right - progress indicator horizontal align
      slider_progress_indicator_align_vert:"{{slider_progress_indicator_align_vert}}",  //top, middle, bottom - progress indicator vertical align
      slider_progress_indicator_offset_hor:{{slider_progress_indicator_offset_hor}},	 //progress indicator horizontal offset 
      slider_progress_indicator_offset_vert:{{slider_progress_indicator_offset_vert}},	 //progress indicator vertical offset
      slider_progressbar_color:"{{slider_progressbar_color}}",			 //progress bar color
      slider_progressbar_opacity: {{slider_progressbar_opacity_nounit}},			 //progress bar opacity
      slider_progressbar_line_width: {{slider_progressbar_line_width_nounit}},			 //progress bar line width
      slider_progresspie_type_fill: false,		 //false is stroke, true is fill - the progress pie type, stroke of fill
      slider_progresspie_color1: "{{slider_progresspie_color1}}", 		 //the first color of the progress pie
      slider_progresspie_stroke_width: {{progress_pie_stroke_width_nounit}},			 //progress pie stroke width
      slider_progresspie_width: {{progress_pie_size_nounit}},			//progess pie width	
      slider_progresspie_height: {{progress_pie_size_nounit}},	         //progress pie height  
      
      slider_enable_play_button: {{slider_enable_play_button}},			 //true,false - enable play / pause button onslider element
      slider_play_button_skin: "",				 //skin of the slider play button, if empty inherit from gallery skin
      slider_play_button_align_hor:"{{slider_play_button_align_hor}}",    	 //left, center, right - play button horizontal align
      slider_play_button_align_vert:"{{slider_play_button_align_vert}}",         //top, middle, bottom - play button vertical align
      slider_play_button_offset_hor:{{slider_play_button_offset_hor}},	       	 //play button horizontal offset 
      slider_play_button_offset_vert:{{slider_play_button_offset_vert}},	   		 //play button vertical offset
      slider_play_button_type: "{{play_button_icon_type}}",          //play button type - default, custom
      slider_play_button_custom: "{{custom_play_button_icon_html|ucsafe|raw}}",          //play button icon custom
      slider_pause_button_custom: "{{custom_pause_button_icon_html|ucsafe|raw}}",          //pause button icon custom                                    
      
      slider_enable_fullscreen_button: {{slider_enable_fullscreen_button}},		 //true,false - enable fullscreen button onslider element
      slider_fullscreen_button_skin: "",			 //skin of the slider fullscreen button, if empty inherit from gallery skin
      slider_fullscreen_button_align_hor:"{{slider_fullscreen_button_align_hor}}",   //left, center, right	- fullscreen button horizonatal align
      slider_fullscreen_button_align_vert:"{{slider_fullscreen_button_align_vert}}",   //top, middle, bottom - fullscreen button vertical align
      slider_fullscreen_button_offset_hor:{{slider_fullscreen_button_offset_hor}},	     //fullscreen button horizontal offset 
      slider_fullscreen_button_offset_vert:{{slider_fullscreen_button_offset_vert}},	   	 //fullscreen button vertical offset
      slider_fullscreen_button_type: "{{fullscreen_button_type}}",    //fullscreen icon type: custom / default
      slider_fullscreen_button_icon_custom: "{{fullscreen_button_icon_html|ucsafe|raw}}",    //custom fullscreen icon html
      slider_smallscreen_button_icon_custom: "{{smallscreen_button_icon_html|ucsafe|raw}}",    //custom small icon html                                 
      
      slider_enable_zoom_panel: {{slider_enable_zoom_panel}},				 //true,false - enable the zoom buttons, works together with zoom control.
      slider_zoompanel_skin: "",					 //skin of the slider zoom panel, if empty inherit from gallery skin		  
      slider_zoompanel_align_hor:"{{slider_zoompanel_align_hor}}",    		 //left, center, right - zoom panel horizontal align
      slider_zoompanel_align_vert:"{{slider_zoompanel_align_vert}}",     	 	 //top, middle, bottom - zoom panel vertical align
      slider_zoompanel_offset_hor:{{slider_zoompanel_offset_hor}},	       		 //zoom panel horizontal offset 
      slider_zoompanel_offset_vert:{{slider_zoompanel_offset_vert}},	   	     //zoom panel vertical offset
      slider_zoom_icons_color: "{{zoom_icons_color}}",
      slider_zoom_icons_type: "{{zoom_icons_type}}", // default / custom
      slider_zoom_icon_plus: "{{zoom_plus_icon_html|ucsafe|raw}}",  //custom plus icon html
      slider_zoom_icon_minus: "{{zoom_minus_icon_html|ucsafe|raw}}",  //custom minus icon html
      slider_zoom_icon_return: "{{zoom_return_icon_html|ucsafe|raw}}",  //custom return icon html                                 
      
      slider_controls_always_on: true,		     //true,false - controls are always on, false - show only on mouseover
      slider_controls_appear_ontap: true,			 //true,false - appear controls on tap event on touch devices
      slider_controls_appear_duration: 300,		 //the duration of appearing controls
      slider_videoplay_button_type: "square",		  //square, round - the videoplay button type, square or round	
      slider_videoplay_icon_type: "{{play_video_button_type}}",		//default, custom - the videoplay icon type
      slider_videoplay_icon_custom: "{{play_video_custom_icon_html|ucsafe|raw}}",		//custom videoplay icon html                
      video_closebutton_type: "{{close_button_type}}",
      video_closebutton_custom: "{{custom_close_button_icon_html|ucsafe|raw}}",                                
      
      slider_enable_text_panel: {{slider_enable_text_panel}},			 //true,false - enable the text panel
      slider_textpanel_always_on: {{text_panel_always_on}},			 //true,false - text panel are always on, false - show only on mouseover
      slider_textpanel_text_valign:"middle",			//middle, top, bottom - text vertical align
      slider_textpanel_padding_top:{{slider_textpanel_padding}},				//textpanel padding top 
      slider_textpanel_padding_bottom:{{slider_textpanel_padding}},				//textpanel padding bottom
      slider_textpanel_padding_right: {{slider_textpanel_padding}},				//cut some space for text from right
      slider_textpanel_padding_left: {{slider_textpanel_padding}},				//cut some space for text from left
      slider_textpanel_height: null,					//textpanel height. if null it will be set dynamically
      slider_textpanel_padding_title_description: 5,	//the space between the title and the description
      slider_textpanel_fade_duration: 200,			//the fade duration of textpanel appear
      slider_textpanel_enable_title: {{slider_textpanel_enable_title}},			//enable the title text
      slider_textpanel_enable_description: true,		//enable the description text
      slider_textpanel_enable_bg: true,				//enable the textpanel background
      slider_textpanel_bg_color:"{{slider_textpanel_bg_color}}",			//textpanel background color
      slider_textpanel_bg_opacity: {{slider_textpanel_bg_opacity_nounit}},				//textpanel background opacity
      
      thumb_width:{{thumb_width_nounit}},								//thumb width
      thumb_height:{{thumb_height_nounit}},							//thumb height
      thumb_fixed_size:true,						//true,false - fixed/dynamic thumbnail width
      
      thumb_border_effect:true,					//true, false - specify if the thumb has border
      thumb_border_width: {{thumb_border_width_nounit}},						//thumb border width
      thumb_border_color: "{{thumb_border_color}}",				//thumb border color
      thumb_over_border_width: {{thumb_over_border_width_nounit}},					//thumb border width in mouseover state
      thumb_over_border_color: "{{thumb_over_border_color}}",			//thumb border color in mouseover state
      thumb_selected_border_width: {{thumb_selected_border_width_nounit}},				//thumb width in selected state
      thumb_selected_border_color: "{{thumb_selected_border_color}}",		//thumb border color in selected state
      
      thumb_round_corners_radius:{{thumb_round_corners_radius_nounit}},				//thumb border radius
      
      thumb_color_overlay_effect: true,			//true,false - thumb color overlay effect, release the overlay on mouseover and selected states
      thumb_overlay_color: "{{thumb_overlay_color}}",				//thumb overlay color
      thumb_overlay_opacity: {{thumb_overlay_opacity_nounit}},					//thumb overlay color opacity
      thumb_overlay_reverse:{{thumb_overlay_reverse}},				//true,false - reverse the overlay, will be shown on selected state only
      thumb_image_overlay_effect: {{thumb_image_overlay_effect}},			//true,false - images overlay effect on normal state only
      thumb_image_overlay_type: "{{thumb_image_overlay_type}}",				//bw , blur, sepia - the type of image effect overlay, black and white, sepia and blur.
      thumb_transition_duration: 200,				//thumb effect transition duration
      thumb_transition_easing: "easeOutQuad",		//thumb effect transition easing        
      strippanel_background_color:"{{thumbs_panel_background_color}}",
      slider_links_newpage: {{open_item_link_on_new_page}},
      strippanel_enable_handle: {{gridpanel_enable_handle}},				//enable grid handle
      strippanel_handle_type: "{{panel_handle_type}}",      //handle type: default, custom
      strippanel_handle_custom_icon: "{{panel_handle_icon_custom_html|ucsafe|raw}}",      //custom handle icon html
      strippanel_background_color:"{{gridpanel_background_color}}",				//background color of the grid wrapper, if not set, it will be taken from the css
      strippanel_handle_icon_color: "{{handle_icon_color_default}}",     
      strip_space_between_thumbs: {{space_between_thumbs}},   
      strippanel_padding_top: {{panel_padding_top}},  
      strippanel_padding_right: {{panel_padding_right}},  
      strippanel_padding_bottom: {{panel_padding_bot}},  
      strippanel_padding_left: {{panel_padding_left}},                                 
    });

  {% if enable_lightbox == "true" %}

    var objItems = objGallery.find(".ug-slide-wrapper");	
    var strJson = {{put_items_json()}};
    var arrItems = JSON.parse(strJson);
	var imageItems = arrItems.map(item => {
        return {
            src: item.images.image,
            caption: item.images.title
        };
    });
	
    const fancyboxOptions = {
        loop: true,
        arrows : true,
        backfocus: false,
        btnTpl: {
          arrowLeft: `<button data-fancybox-prev class="fancybox-button fancybox-button--arrow_left" title="prev">` +
            `<div>{{previous_arrow_icon_html|ucsafe|raw}}</div>` +
            `</button>`,
          arrowRight: `<button data-fancybox-next class="fancybox-button fancybox-button--arrow_right" title="next">` +
            `<div>{{next_arrow_icon_html|ucsafe|raw}}</div>` +
            `</button>`,
          },
        {% if disable_zoom_in_after_lightbox_image_click == "true" %}
          clickContent: "next",
        {% endif %}     
    };

    objGallery.find('.ug-slider-wrapper').on('click', function(e) {
      var objTarget = jQuery(e.target);
      var objParentLink = objTarget.closest("a");

      if(objTarget.tagName == "A" || objParentLink && objParentLink.length > 0){
        var href = objTarget.attr("href") || objParentLink.attr("href");

        if(href == "#")
          e.preventDefault();
      }

      var selectedIndex = objGallery.data().unitegalleryApi.getNumCurrent();
	
      jQuery.fancybox.open(imageItems, {
          ...fancyboxOptions,
          index: selectedIndex
        });
    });

  {% endif %}
    
    {{ucfunc("put_remote_parent_js","objGallery","unitegallery")}}  
    
    objGallery.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      	
      api.changeItems(htmlItems); 
      
      if(!htmlItems)
        api.showMessageReplaceGallery("{{empty_message|ucsafe|raw}}"); 
    });
    	
{{ ucfunc("put_docready_end") }}