{{ ucfunc("put_docready_start") }}
		
  var objWrapper = jQuery("#{{uc_id}}");
  var options = {
      
      gallery_theme:"tiles",
      gallery_width:"{{gallery_width}}",
      
      tiles_type: "{{gallery_type}}",   
      tiles_align:"{{tiles_align}}",
      tiles_col_width:{{tiles_col_width_nounit}},
      tiles_justified_space_between:{{tiles_space_between_cols_nounit}},                                 
      tiles_space_between_cols:{{tiles_space_between_cols_nounit}},
      tiles_space_between_cols_mobile: {{tiles_space_between_cols_mobile_nounit}},
      tile_as_link: {{tile_as_link}},
      tile_link_newpage: {{tile_link_newpage}},
      tiles_min_columns: {{tiles_min_columns_nounit}},
      tile_overlay_opacity: {{tile_overlay_opacity_nounit}},
      tile_overlay_color: "{{tile_overlay_color}}",   
      tile_background_color: "{{tile_background_color}}",                               
      slider_video_autoplay:{{autoplay_video_in_lightbox}},
      
      
      {% if tile_enable_border == "true" %}
      tile_enable_border:{{tile_enable_border}},
      tile_border_color:"{{tile_border_color}}",
      tile_border_width:{{tile_border_width_nounit}},
      tile_border_radius:{{tile_border_radius_nounit}}, 
      
      {% endif %}	
      
      {% if tile_enable_shadow == "true" %}
      tile_enable_shadow:{{tile_enable_shadow}},
      tile_shadow_color:"{{tile_shadow_color}}",
      tile_shadow_h:{{tile_shadow_h_nounit}},					
      tile_shadow_v:{{tile_shadow_v_nounit}},					
      tile_shadow_blur:{{tile_shadow_blur_nounit}},					
      tile_shadow_spread:{{tile_shadow_spread_nounit}},
      {% endif %}                               
      
      {% if tile_enable_image_effect == "true" %}
      tile_enable_image_effect:{{tile_enable_image_effect}},
      tile_image_effect_type: "{{tile_image_effect_type}}",
      tile_image_effect_reverse: {{tile_image_effect_reverse}},
      {% endif %}   
      
      tile_enable_textpanel:{{tile_enable_textpanel}},
      tile_textpanel_source:"{{text_panel_source}}",
      tile_textpanel_always_on: {{tile_textpanel_always_on}},
      tile_textpanel_appear_type: "{{tile_textpanel_appear_type}}",
      tile_textpanel_position:"{{tile_textpanel_position}}",
      tile_textpanel_padding_top:{{tile_textpanel_padding_nounit}},		 	
      tile_textpanel_padding_bottom:{{tile_textpanel_padding_nounit}},	 	
      tile_textpanel_padding_right: {{tile_textpanel_padding_nounit}},	 	
      tile_textpanel_padding_left: {{tile_textpanel_padding_nounit}},
      tile_textpanel_bg_color:"{{tile_textpanel_bg_color}}",
      tile_textpanel_bg_opacity:{{tile_textpanel_bg_opacity_nounit}},
      tile_textpanel_title_text_align:"{{tile_textpanel_title_text_align}}",
      tile_textpanel_title_color:"{{tile_textpanel_title_color}}",
      
      lightbox_type: "{{lightbox_type}}",
      lightbox_hide_arrows_onvideoplay: {{lightbox_hide_arrows_onvideoplay}},
      lightbox_arrows_position: "{{lightbox_arrows_position}}",                                
      lightbox_overlay_color:"{{lightbox_overlay_color}}",
      lightbox_overlay_opacity:{{lightbox_overlay_opacity_nounit}},	
      lightbox_show_numbers: {{lightbox_show_numbers}},
      lightbox_show_textpanel: {{lightbox_show_textpanel}},
      lightbox_slider_control_swipe:{{lightbox_slider_control_swipe}},
      lightbox_slider_control_zoom:{{lightbox_slider_control_zoom}},
      lightbox_textpanel_title_text_align:"{{lightbox_textpanel_title_text_align}}",
      
      lightbox_slider_image_border: {{lightbox_slider_image_border}},
      lightbox_slider_image_border_width: {{lightbox_slider_image_border_width_nounit}},
      lightbox_slider_image_border_color: "{{lightbox_slider_image_border_color}}",
      lightbox_slider_image_border_radius: {{lightbox_slider_image_border_radius_nounit}},
      lightbox_close_icon_type: "{{lightbox_close_icon_type}}",        //close icon type: default, custom
      lightbox_close_icon_color: "{{lightbox_close_icon_color_default}}",        //close icon color
      lightbox_close_icon_color_custom: "{{lightbox_close_icon_color_custom}}",  
      lightbox_close_icon_custom: `{{lightbox_close_icon_custom_html|ucsafe|raw}}`,        //close icon custom html  
      lightbox_close_icon_size_custom: "{{lightbox_close_icon_size_custom_nounit}}",
      lightbox_arrows_type: "{{lightbox_arrows_icon_type}}",        //arrow type: default, custom
      lightbox_arrows_color: "{{lightbox_arrows_icon_color_default}}",        //arrow color
      lightbox_arrows_color_custom: "{{lightbox_arrows_icon_color_custom}}",        //arrow color
      lightbox_arrow_next_custom: `{{lightbox_arrows_icon_next_html|ucsafe|raw}}`,        //arrow html
      lightbox_arrow_prev_custom: `{{lightbox_arrows_icon_prev_html|ucsafe|raw}}`,        //arrow html
      lightbox_arrows_size_custom: {{lightbox_arrows_icon_size_custom_nounit}},        //arrow size custom
      slider_video_muted: {{mute_video}},   
      
      tile_enable_icons: {{tile_enable_icons}},
      tile_icon_type: "{{tile_icons_type}}",				//tile icon type: default / custom
      tile_zoom_icon_color: "{{zoom_icon_color_def}}",      //tile icon color
      tile_play_icon_color: "{{play_icon_color_def}}",      //tile icon color
      tile_link_icon_color: "{{link_icon_color_def}}",      //tile icon color
      tile_zoom_icon_custom: `{{tile_zoom_icon_custom_html|ucsafe|raw}}`,				//tile zoom icon type: default / custom
      tile_play_icon_custom: `{{tile_play_icon_custom_html|ucsafe|raw}}`,				//tile play icon type: default / custom
      tile_link_icon_custom: `{{tile_link_icon_custom_html|ucsafe|raw}}`,				//tile link icon type: default / custom        
    }
    
    var api = objWrapper.unitegallery(options);
    
    objWrapper.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      
      if(isAppend == true)
        api.addItems(htmlItems);         
      else
      api.changeItems(htmlItems);  
      
      if(!htmlItems)
        api.showMessageReplaceGallery("{{empty_message|ucsafe|raw}}");      
    });
    
    //native pagination feature
    var objContentGrid = jQuery('#wrapper{{uc_id}}');
    var objItems = objContentGrid.find(".ug-thumb-wrapper");
    var objPaginationNumbers = objContentGrid.find(".uc_post_grid_style_one_pagination_numbers");
    var pobjPaginatedList = objContentGrid.find(".uc_post_grid_style_one_wrap");
    var objNextButton = objContentGrid.find(".uc_post_grid_style_one_next_button");
    var objPrevButton = objContentGrid.find(".uc_post_grid_style_one_prev_button");
    var itemsPerPage = Number("{{items_number_per_page}}");
    var totalItems = objItems.length;
    var pageCount = Math.ceil(totalItems / itemsPerPage);
    var currentPage = 1;
    var isPagesEnabled = "{{enable_pagination}}";
    
    var classActive = "ue-active";
    var classVisible = "ue-visible";
    var classDisabled = "ue-disabled";
    var classHidden = "ue-hidden";
    var classSelected = "ue-selected";
    var classPageNumber = "uc_post_grid_style_one_pagination_number";
    
    var strJson = {{put_items_json()}};
    var arrItems = JSON.parse(strJson);   
    
    /**
    * scroll to top
    */
    function scrollToTop(obj, num){
      var offsetTop = obj.offset().top;
      
      jQuery("html").animate({ scrollTop: (offsetTop + num) }, 500);
    }
    
    /**
    * disable button
    */
    function disableButton(objButton){
      objButton.addClass(classDisabled);
    }
    
    /**
    * enable button
    */
    function enableButton(objButton){
      objButton.removeClass(classDisabled);
    }
    
    /**
    * handle status
    */
    function handlePageButtonsStatus(){
      if (currentPage === 1) {
        disableButton(objPrevButton);
      } else {
        enableButton(objPrevButton);
      }
      
      if (pageCount === currentPage) {
        disableButton(objNextButton);
      } else {
        enableButton(objNextButton);
      }
      
      setTimeout(function(){
        var objPages = objContentGrid.find("."+classPageNumber);
        
        if(!objPages || objPages.length == 0){
          disableButton(objPrevButton);
          disableButton(objNextButton);
        } 
      },300);      
    }
    
    /**
    * handle active state
    */
    function handleActivePageNumber(){
      const pagesNum = document.querySelectorAll("."+classPageNumber).length;
      
      document.querySelectorAll("."+classPageNumber).forEach((button) => {
        button.classList.remove(classActive);
        button.classList.remove(classVisible); 
        
        const pageIndex = Number(button.getAttribute("page-index"));
        
        if (pageIndex == currentPage) {
          button.classList.add(classActive);        
        }        
      });
    }
    
    /*
    ** append nums
    */
    function appendPageNumber(index){
      const pageNumber = document.createElement("button");
      pageNumber.className = classPageNumber;
      pageNumber.innerHTML = index;
      pageNumber.setAttribute("page-index", index);
      pageNumber.setAttribute("aria-label", "Page " + index);
      
      objPaginationNumbers[0].appendChild(pageNumber);
    }
    
    /**
    * returns pages num
    */
    function setPaginationNumbers(){
      for (let i = 1; i <= pageCount; i++) {
        appendPageNumber(i);
      }
    }
    
    /**
    * get current item by index
    */
    function getCurrentItem(item){
      var obj = jQuery(item);
      var objImg = obj.find("img"); 
      var index = obj.index();
      var lightboxImageSrc = arrItems[index].images.image;
      var dataTitle = arrItems[index].images.title;
      var dataDescr = arrItems[index].images.description;
      var dataType = arrItems[index].images.type;
      var dataMP4 = arrItems[index].images.url_mp4;
      var dataVideoID = arrItems[index].images.videoid;
      
      var src = objImg.attr("src");
      var htmlToAdd = `<a href=""/><img src="${src}" data-image="${lightboxImageSrc}" data-title="${dataTitle}" data-description="${dataDescr}" data-type="${dataType}" data-videomp4="${dataMP4}" data-videoid="${dataVideoID}" alt="" />`;
      
      return(htmlToAdd);
    }
    
    /**
    * sets current page
    */
    function setCurrentPage(pageNum, isFiltered, isScrollToTop){
      currentPage = Number(pageNum);
      
      handleActivePageNumber();
      handlePageButtonsStatus();
      
      const prevRange = (pageNum - 1) * itemsPerPage;
      const currRange = pageNum * itemsPerPage;
      
      // Get the filtered items if isFiltered is true
      let itemsToDisplay;
      
      if (isFiltered) {
        itemsToDisplay = objItems.filter('.'+classSelected);
      } else {
        itemsToDisplay = objItems;
      }
      
      // Calculate total number of filtered items
      const totalFilteredItems = itemsToDisplay.length;
      
      // Hide all items first
      objItems.each(function(index, item) {
        item.classList.add(classHidden);
      });      
      
      // Show filtered items if available
      if (isFiltered && totalFilteredItems > 0) {
        itemsToDisplay.each(function(index, item) {
          // Check if the index falls within the current page range
          if (index >= prevRange && index < currRange) {
            item.classList.remove(classHidden); // Show the item if it's in range            
          }
        });
      } else {
        var galleryItems = [];
        
        // If no filtering or no filtered items, show all items in range
        objItems.each(function(index, item) {
          
          if (index >= prevRange && index < currRange) {
            item.classList.remove(classHidden); // Show the item if it's in range
            
            galleryItems += getCurrentItem(item);
          }
        });
        
        api.changeItems(galleryItems); //resizes the widget
      }
      
      if(isScrollToTop)
        scrollToTop(objContentGrid, -80, false);
    }; 
    
    /**
    * get all gallery items
    */
    function getAllGalleryItems(){
      var allGalleryItems;
      
      objItems.each(function(){
        var obj = jQuery(this);
        var objImg = obj.find("img");
        var src = objImg.attr("src");
        var htmlToAdd = `<a href=""/><img src="${src}" />`
        
        allGalleryItems+=htmlToAdd;
      });
      
      return(allGalleryItems);
    }   
    
    if(isPagesEnabled == "true" && `{{multisource}}` != "posts"){
      
      setTimeout(function(){
        setPaginationNumbers();
        setCurrentPage(1, true, false);
        var htmlVisibleItems = objContentGrid.find(".ug-thumb-wrapper:not(.ue-hidden)");
        
        //init events
        objPrevButton.on("click", function(){
          setCurrentPage(currentPage - 1, true, true);
        });
        
        objNextButton.on("click", function(){
          setCurrentPage(currentPage + 1, true, true);
          
        });
        
        objContentGrid.on("click", "."+classPageNumber, function(){
          var objButton = jQuery(this);
          var pageIndex = objButton.attr("page-index");
          
          if(pageIndex){
            setCurrentPage(pageIndex, true, true);
          }
        });     
      },500)
    }
    	
{{ ucfunc("put_docready_end") }}