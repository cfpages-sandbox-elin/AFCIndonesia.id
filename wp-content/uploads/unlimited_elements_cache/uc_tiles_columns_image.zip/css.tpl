#{{uc_id}}{
  margin:0 auto;
  {% if uc_inside_editor == "no" %}
    display: none;
  {% endif %}
}

#wrapper{{uc_id}}{
  min-height:1px;  
}

{% if lightbox_type == "none" %}
  #{{uc_id}} .ug-thumb-wrapper.ug-tile{
      pointer-events: none;
  }
{% endif %}

/* pagination */
#wrapper{{uc_id}} .uc_post_grid_style_one_prev_button_pagination{
  display: flex;
  align-items: center;
}

#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_button,
#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_number{
  padding: 0;
  justify-content: center;
  align-items: center;
  transition: all .3s ease;
  margin: 0;
}

#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_number:last-child,
#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_number:first-child{
  display: inline-flex;
  position: relative;
}

#wrapper{{uc_id}} .ue-hidden{
  display: none;
}

#wrapper{{uc_id}} .ue-disabled{
  opacity: .5;
  pointer-events: none;
}

#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_number.ue-visible{
  display: inline-flex;
}

#wrapper{{uc_id}} .uc_post_grid_style_one_pagination_numbers{
  display: flex;
  flex-wrap: wrap;
}

#wrapper{{uc_id}} .uc_post_grid_style_one_prev_button_pagination_wrap{
  display: flex;
}
/* end pagination */