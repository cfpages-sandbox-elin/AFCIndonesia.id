<div id="wrapper{{uc_id}}">
  
  <div id="{{uc_id}}" style="display:none;" class="uc-items-wrapper{{uc_filtering_addclass}}" data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
    {{put_items()}}
  </div>
  
  {% if enable_pagination == "true" and multisource != "posts" %}
    <div class="uc_post_grid_style_one_prev_button_pagination">
      <div class="uc_post_grid_style_one_prev_button_pagination_wrap">
        {% if show_prev_next_page_button == "true" %}<button class="uc_post_grid_style_one_prev_button uc_post_grid_style_one_pagination_button" aria-label="prev-btn">{{prev_icon_html|raw}}</button>{% endif %}
        <div class="uc_post_grid_style_one_pagination_numbers"></div>
        {% if show_prev_next_page_button == "true" %}<button class="uc_post_grid_style_one_next_button uc_post_grid_style_one_pagination_button" aria-label="next-btn">{{next_icon_html|raw}}</button>{% endif %}
      </div>{# end uc_post_grid_style_one_prev_button_pagination_wrap #}{##}
    </div>{# end uc_post_grid_style_one_prev_button_pagination #}{##}
  {% endif %}{# end show_pagination #}{##}
  
</div>